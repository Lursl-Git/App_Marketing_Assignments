import SwiftUI

struct ContentView: View {
    @State private var showARView = false
    @State private var isAnimating = false
    @Environment(\.colorScheme) var colorScheme
    
    var body: some View {
        ZStack {
            // Hintergrund
            LinearGradient(
                gradient: Gradient(colors: gradientColors),
                startPoint: .topLeading,
                endPoint: .bottomTrailing
            )
            .ignoresSafeArea()
            
            VStack(spacing: 0) {
                Spacer()
                
                // Logo und Titel
                VStack(spacing: 25) {
                    // App Icon
                    Image("AppIconImage")
                        .resizable()
                        .aspectRatio(contentMode: .fit)
                        .frame(width: 140, height: 140)
                        .cornerRadius(30)
                        .shadow(color: Color.black.opacity(0.3), radius: 20, x: 0, y: 10)
                        .scaleEffect(isAnimating ? 1.05 : 1.0)
                        .animation(
                            Animation.easeInOut(duration: 2.0)
                                .repeatForever(autoreverses: true),
                            value: isAnimating
                        )
                    
                    // App Titel
                    Text("AR Viewer")
                        .font(.system(size: 44, weight: .bold, design: .rounded))
                        .foregroundColor(.white)
                    
                    // Untertitel
                    Text("Erlebe 3D-Modelle in deiner Umgebung")
                        .font(.system(size: 17, weight: .medium))
                        .foregroundColor(.white.opacity(0.9))
                        .multilineTextAlignment(.center)
                        .padding(.horizontal, 40)
                }
                
                Spacer()
                
                // AR Start Button
                VStack(spacing: 20) {
                    Button(action: {
                        showARView = true
                    }) {
                        HStack(spacing: 12) {
                            Image(systemName: "arkit")
                                .font(.system(size: 24, weight: .semibold))
                            
                            Text("AR Experience starten")
                                .font(.system(size: 18, weight: .semibold))
                        }
                        .foregroundColor(buttonTextColor)
                        .frame(maxWidth: .infinity)
                        .frame(height: 60)
                        .background(
                            RoundedRectangle(cornerRadius: 16)
                                .fill(Color.white)
                                .shadow(color: Color.black.opacity(0.2), radius: 15, x: 0, y: 8)
                        )
                    }
                    .padding(.horizontal, 40)
                    
                    // Info Text
                    HStack(spacing: 8) {
                        Image(systemName: "info.circle")
                            .font(.system(size: 14))
                        Text("Funktioniert nur auf echten iOS-Geräten")
                            .font(.system(size: 14, weight: .regular))
                    }
                    .foregroundColor(.white.opacity(0.7))
                }
                .padding(.bottom, 60)
            }
        }
        .fullScreenCover(isPresented: $showARView) {
            ARViewContainer()
        }
        .onAppear {
            isAnimating = true
        }
    }
    
    // Gradient-Farben
    private var gradientColors: [Color] {
        if colorScheme == .dark {
            return [
                Color(red: 0.1, green: 0.2, blue: 0.4),
                Color(red: 0.2, green: 0.1, blue: 0.3)
            ]
        } else {
            return [
                Color(red: 0.3, green: 0.5, blue: 0.9),
                Color(red: 0.6, green: 0.3, blue: 0.8)
            ]
        }
    }
    
    // Button-Textfarbe
    private var buttonTextColor: Color {
        colorScheme == .dark ? Color(red: 0.2, green: 0.3, blue: 0.6) : Color(red: 0.3, green: 0.4, blue: 0.8)
    }
}

#Preview {
    ContentView()
}
