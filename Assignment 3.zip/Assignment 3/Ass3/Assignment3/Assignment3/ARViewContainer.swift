import SwiftUI
import RealityKit
import ARKit

struct ARViewContainer: View {
    @Environment(\.presentationMode) var presentationMode

    var body: some View {
        ZStack {
            ARViewRepresentable()
                .ignoresSafeArea()

            // Close Button
            VStack {
                HStack {
                    Spacer()
                    Button(action: { presentationMode.wrappedValue.dismiss() }) {
                        Image(systemName: "xmark.circle.fill")
                            .font(.system(size: 35))
                            .foregroundColor(.white)
                            .shadow(radius: 5)
                    }
                    .padding()
                }

                Spacer()

                // Instruction Panel
                VStack(spacing: 8) {
                    Text("Tippe auf eine Fläche, um die Tasse zu platzieren.")
                        .font(.callout)
                        .foregroundColor(.white)
                    Text("Pinch = Größe (Zoom), Ziehen = Verschieben, Drehen = Rotation.")
                        .font(.footnote)
                        .foregroundColor(.white.opacity(0.85))
                }
                .padding(12)
                .background(Color.black.opacity(0.6))
                .cornerRadius(12)
                .padding(.bottom, 40)
            }
        }
    }
}

struct ARViewRepresentable: UIViewRepresentable {

    func makeCoordinator() -> Coordinator {
        Coordinator()
    }

    func makeUIView(context: Context) -> ARView {
        let arView = ARView(frame: .zero)
        context.coordinator.arView = arView

        // AR Session Configuration
        let config = ARWorldTrackingConfiguration()
        config.planeDetection = [.horizontal, .vertical]
        config.environmentTexturing = .automatic
        arView.session.run(config, options: [.resetTracking, .removeExistingAnchors])

        // Coaching Overlay (hilft bei Plane-Erkennung)
        let coaching = ARCoachingOverlayView()
        coaching.session = arView.session
        coaching.goal = .anyPlane
        coaching.translatesAutoresizingMaskIntoConstraints = false
        arView.addSubview(coaching)
        NSLayoutConstraint.activate([
            coaching.topAnchor.constraint(equalTo: arView.topAnchor),
            coaching.bottomAnchor.constraint(equalTo: arView.bottomAnchor),
            coaching.leadingAnchor.constraint(equalTo: arView.leadingAnchor),
            coaching.trailingAnchor.constraint(equalTo: arView.trailingAnchor),
        ])

        // Model einmal laden (und später klonen)
        context.coordinator.loadModelIfNeeded()

        // Tap-to-place
        let tap = UITapGestureRecognizer(target: context.coordinator, action: #selector(Coordinator.handleTap(_:)))
        arView.addGestureRecognizer(tap)

        return arView
    }

    func updateUIView(_ uiView: ARView, context: Context) { }

    final class Coordinator: NSObject {
        weak var arView: ARView?

        private var baseModel: ModelEntity?
        private var currentAnchor: AnchorEntity?

        // Tassengröße
        private var currentScale: Float = 0.03

        func loadModelIfNeeded() {
            guard baseModel == nil else { return }
            do {
                // Model Benennung
                let model = try ModelEntity.loadModel(named: "model.usdz")
                baseModel = model
            } catch {
                print("Fehler beim Laden des Models: \(error.localizedDescription)")
            }
        }

        @objc func handleTap(_ recognizer: UITapGestureRecognizer) {
            guard let arView else { return }
            loadModelIfNeeded()

            let location = recognizer.location(in: arView)

    
            let query =
                arView.makeRaycastQuery(from: location, allowing: .existingPlaneGeometry, alignment: .any) ??
                arView.makeRaycastQuery(from: location, allowing: .estimatedPlane, alignment: .any)

            if let query,
               let result = arView.session.raycast(query).first {
                placeModel(worldTransform: result.worldTransform)
            } else {
                // Fallback falls keine Fläche gefunden wird
                placeInFrontOfCamera(distanceMeters: 0.6)
            }
        }

        private func placeModel(worldTransform: simd_float4x4) {
            guard let arView, let baseModel else { return }

            // Altes Placement entfernen
            if let currentAnchor {
                arView.scene.removeAnchor(currentAnchor)
            }

            // Anchor an exakt dem Tap-Punkt
            let anchor = AnchorEntity(world: worldTransform)

        
            let entity = baseModel.clone(recursive: true)
            entity.transform.scale = SIMD3<Float>(repeating: currentScale)

            anchor.addChild(entity)
            arView.scene.addAnchor(anchor)
            currentAnchor = anchor
        }

        private func placeInFrontOfCamera(distanceMeters: Float) {
            guard let arView else { return }
            var transform = arView.cameraTransform.matrix

            let forward = -SIMD3<Float>(transform.columns.2.x, transform.columns.2.y, transform.columns.2.z)
            let camPos = SIMD3<Float>(transform.columns.3.x, transform.columns.3.y, transform.columns.3.z)
            let newPos = camPos + normalize(forward) * distanceMeters

            transform.columns.3 = SIMD4<Float>(newPos.x, newPos.y, newPos.z, 1)
            placeModel(worldTransform: transform)
        }
    }
}
