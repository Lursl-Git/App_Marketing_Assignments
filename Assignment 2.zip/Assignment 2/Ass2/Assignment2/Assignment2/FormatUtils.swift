import Foundation

enum FormatUtils {
    static func distance(_ meters: Double) -> String {
        if meters < 1000 { return "\(Int(meters)) m" }
        return String(format: "%.2f km", meters / 1000.0)
    }

    static func duration(_ seconds: TimeInterval) -> String {
        let s = Int(seconds)
        let m = s / 60
        let r = s % 60
        return String(format: "%02d:%02d", m, r)
    }
}
