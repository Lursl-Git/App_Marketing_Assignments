import SwiftUI
import MapKit

struct NavigationDetailView: View {
    @ObservedObject var viewModel: MapViewModel
    @ObservedObject var locationManager: LocationManager
    @Environment(\.dismiss) var dismiss
    
    var body: some View {
        NavigationView {
            ScrollView {
                VStack(alignment: .leading, spacing: 20) {
                    // Route Summary
                    RouteSummaryCard(
                        distance: viewModel.totalDistance,
                        time: viewModel.estimatedTime,
                        stops: viewModel.tourStops.count
                    )
                    
                    // Elevation Profile
                    if !viewModel.currentRoute.isEmpty {
                        ElevationProfileView(route: viewModel.currentRoute)
                    }
                    
                    // Turn-by-turn instructions
                    VStack(alignment: .leading, spacing: 15) {
                        Text("Navigation Instructions")
                            .font(.headline)
                            .padding(.horizontal)
                        
                        ForEach(Array(viewModel.navigationInstructions.enumerated()), id: \.element.id) { index, instruction in
                            NavigationInstructionRow(
                                instruction: instruction,
                                isActive: index == 0,
                                currentLocation: locationManager.location?.coordinate
                            )
                        }
                    }
                    
                    // Tour Stops List
                    VStack(alignment: .leading, spacing: 15) {
                        Text("Tour Stops")
                            .font(.headline)
                            .padding(.horizontal)
                        
                        ForEach(viewModel.tourStops.sorted { $0.order < $1.order }) { stop in
                            TourStopRow(stop: stop)
                        }
                    }
                }
                .padding(.vertical)
            }
            .navigationTitle("Navigation")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button("Done") {
                        dismiss()
                    }
                }
            }
        }
    }
}

struct RouteSummaryCard: View {
    let distance: Double
    let time: Double
    let stops: Int
    
    var body: some View {
        VStack(spacing: 15) {
            HStack(spacing: 30) {
                VStack {
                    Image(systemName: "map")
                        .font(.title)
                        .foregroundColor(.blue)
                    Text("\(distance / 1000, specifier: "%.2f") km")
                        .font(.headline)
                    Text("Distance")
                        .font(.caption)
                        .foregroundColor(.secondary)
                }
                
                VStack {
                    Image(systemName: "clock")
                        .font(.title)
                        .foregroundColor(.green)
                    Text("\(Int(time)) min")
                        .font(.headline)
                    Text("Time")
                        .font(.caption)
                        .foregroundColor(.secondary)
                }
                
                VStack {
                    Image(systemName: "flag.fill")
                        .font(.title)
                        .foregroundColor(.orange)
                    Text("\(stops)")
                        .font(.headline)
                    Text("Stops")
                        .font(.caption)
                        .foregroundColor(.secondary)
                }
            }
        }
        .frame(maxWidth: .infinity)
        .padding()
        .background(Color(.systemBackground))
        .cornerRadius(15)
        .shadow(radius: 5)
        .padding(.horizontal)
    }
}

struct NavigationInstructionRow: View {
    let instruction: NavigationInstruction
    let isActive: Bool
    let currentLocation: CLLocationCoordinate2D?
    
    var distanceToInstruction: String {
        guard let current = currentLocation else { return "N/A" }
        let fromLocation = CLLocation(latitude: current.latitude, longitude: current.longitude)
        let toLocation = CLLocation(latitude: instruction.coordinate.latitude, longitude: instruction.coordinate.longitude)
        let distance = fromLocation.distance(from: toLocation)
        
        if distance < 1000 {
            return "\(Int(distance))m"
        } else {
            let km = distance / 1000
                return String(format: "%.1f km", km)
        }
    }
    
    var body: some View {
        HStack(spacing: 15) {
            ZStack {
                Circle()
                    .fill(isActive ? Color.blue : Color.gray.opacity(0.3))
                    .frame(width: 40, height: 40)
                
                Text("\(instruction.step)")
                    .font(.headline)
                    .foregroundColor(isActive ? .white : .gray)
            }
            
            VStack(alignment: .leading, spacing: 5) {
                Text(instruction.description)
                    .font(.subheadline)
                    .fontWeight(isActive ? .semibold : .regular)
                
                HStack(spacing: 15) {
                    Label(distanceToInstruction, systemImage: "location.fill")
                        .font(.caption)
                        .foregroundColor(.secondary)
                    
                    Label("\(instruction.elevation, specifier: "%.0f")m", systemImage: "mountain.2")
                        .font(.caption)
                        .foregroundColor(.secondary)
                }
            }
            
            Spacer()
            
            if isActive {
                Image(systemName: "arrow.right.circle.fill")
                    .foregroundColor(.blue)
                    .font(.title2)
            }
        }
        .padding()
        .background(isActive ? Color.blue.opacity(0.1) : Color(.systemBackground))
        .cornerRadius(10)
        .padding(.horizontal)
    }
}

struct TourStopRow: View {
    let stop: TourStop
    
    var body: some View {
        HStack(spacing: 15) {
            ZStack {
                Circle()
                    .fill(Color.orange)
                    .frame(width: 35, height: 35)
                
                Text("\(stop.order)")
                    .font(.subheadline)
                    .fontWeight(.bold)
                    .foregroundColor(.white)
            }
            
            VStack(alignment: .leading, spacing: 5) {
                Text(stop.name)
                    .font(.subheadline)
                    .fontWeight(.semibold)
                
                HStack(spacing: 10) {
                    Text("\(stop.coordinate.latitude, specifier: "%.4f"), \(stop.coordinate.longitude, specifier: "%.4f")")
                        .font(.caption)
                        .foregroundColor(.secondary)
                    
                    Label("\(stop.elevation, specifier: "%.0f")m", systemImage: "mountain.2")
                        .font(.caption)
                        .foregroundColor(.secondary)
                }
            }
            
            Spacer()
        }
        .padding()
        .background(Color(.systemBackground))
        .cornerRadius(10)
        .padding(.horizontal)
    }
}

struct ElevationProfileView: View {
    let route: [CLLocationCoordinate2D]
    @State private var elevationData: [Double] = []
    
    var body: some View {
        VStack(alignment: .leading, spacing: 10) {
            Text("Elevation Profile")
                .font(.headline)
                .padding(.horizontal)
            
            if elevationData.isEmpty {
                ProgressView("Loading elevation data...")
                    .frame(height: 150)
            } else {
                ElevationChart(data: elevationData)
                    .frame(height: 150)
                    .padding(.horizontal)
            }
        }
        .padding(.vertical)
        .background(Color(.systemBackground))
        .cornerRadius(15)
        .shadow(radius: 3)
        .padding(.horizontal)
        .task {
            await loadElevationData()
        }
    }
    
    private func loadElevationData() async {
        let service = ElevationService()
        elevationData = await service.getElevationProfile(for: route)
    }
}

struct ElevationChart: View {
    let data: [Double]
    
    var body: some View {
        GeometryReader { geometry in
            let maxElevation = data.max() ?? 0
            let minElevation = data.min() ?? 0
            let elevationRange = maxElevation - minElevation
            
            ZStack {
                // Background
                RoundedRectangle(cornerRadius: 10)
                    .fill(Color(.systemGray6))
                
                // Elevation line
                Path { path in
                    guard !data.isEmpty else { return }
                    
                    let stepX = geometry.size.width / CGFloat(data.count - 1)
                    
                    for (index, elevation) in data.enumerated() {
                        let x = CGFloat(index) * stepX
                        let normalizedHeight = elevationRange > 0 ? (elevation - minElevation) / elevationRange : 0.5
                        let y = geometry.size.height * (1 - normalizedHeight)
                        
                        if index == 0 {
                            path.move(to: CGPoint(x: x, y: y))
                        } else {
                            path.addLine(to: CGPoint(x: x, y: y))
                        }
                    }
                }
                .stroke(Color.green, lineWidth: 2)
                
                // Fill area under line
                Path { path in
                    guard !data.isEmpty else { return }
                    
                    let stepX = geometry.size.width / CGFloat(data.count - 1)
                    
                    path.move(to: CGPoint(x: 0, y: geometry.size.height))
                    
                    for (index, elevation) in data.enumerated() {
                        let x = CGFloat(index) * stepX
                        let normalizedHeight = elevationRange > 0 ? (elevation - minElevation) / elevationRange : 0.5
                        let y = geometry.size.height * (1 - normalizedHeight)
                        path.addLine(to: CGPoint(x: x, y: y))
                    }
                    
                    path.addLine(to: CGPoint(x: geometry.size.width, y: geometry.size.height))
                    path.closeSubpath()
                }
                .fill(
                    LinearGradient(
                        colors: [Color.green.opacity(0.3), Color.green.opacity(0.05)],
                        startPoint: .top,
                        endPoint: .bottom
                    )
                )
                
                // Labels
                VStack {
                    HStack {
                        Text("\(Int(maxElevation))m")
                            .font(.caption2)
                            .foregroundColor(.secondary)
                        Spacer()
                    }
                    Spacer()
                    HStack {
                        Text("\(Int(minElevation))m")
                            .font(.caption2)
                            .foregroundColor(.secondary)
                        Spacer()
                    }
                }
                .padding(5)
            }
        }
    }
}
