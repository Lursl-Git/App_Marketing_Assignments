import Foundation
import MapKit

struct UserMarker: Identifiable, Codable, Equatable {
    var id: UUID
    var title: String
    var note: String
    var coordinate: CodableCoordinate
    var createdAt: Date

    init(id: UUID = UUID(), title: String = "Marker", note: String = "", coordinate: CLLocationCoordinate2D, createdAt: Date = Date()) {
        self.id = id
        self.title = title
        self.note = note
        self.coordinate = CodableCoordinate(coordinate)
        self.createdAt = createdAt
    }

    var clCoordinate: CLLocationCoordinate2D { coordinate.coordinate }
}

struct UserMarkerStore {
    private let key = "kuladig_user_markers_v1"

    func load() -> [UserMarker] {
        guard let data = UserDefaults.standard.data(forKey: key) else { return [] }
        return (try? JSONDecoder().decode([UserMarker].self, from: data)) ?? []
    }

    func save(_ markers: [UserMarker]) {
        guard let data = try? JSONEncoder().encode(markers) else { return }
        UserDefaults.standard.set(data, forKey: key)
    }
}
