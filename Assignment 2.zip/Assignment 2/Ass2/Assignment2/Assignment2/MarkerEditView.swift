import SwiftUI
import MapKit

struct MarkerEditView: View {
    @Environment(\.dismiss) private var dismiss

    let marker: UserMarker
    @ObservedObject var viewModel: MapViewModel
    @ObservedObject var locationManager: LocationManager

    @State private var title: String
    @State private var note: String

    init(marker: UserMarker, viewModel: MapViewModel, locationManager: LocationManager) {
        self.marker = marker
        self.viewModel = viewModel
        self.locationManager = locationManager
        _title = State(initialValue: marker.title)
        _note  = State(initialValue: marker.note)
    }

    var body: some View {
        NavigationStack {
            Form {
                Section("Name") {
                    TextField("Titel", text: $title)
                }

                Section("Notiz") {
                    TextField("Optional", text: $note, axis: .vertical)
                        .lineLimit(3...6)
                }

                Section("Position") {
                    Text("Lat \(marker.clCoordinate.latitude, specifier: "%.5f") • Lon \(marker.clCoordinate.longitude, specifier: "%.5f")")
                        .font(.caption)
                        .foregroundStyle(.secondary)

                    Button("Auf aktuelle Position setzen") {
                        guard let c = locationManager.location?.coordinate else { return }
                        viewModel.updateMarker(id: marker.id, title: title, note: note, newCoordinate: c)
                        dismiss()
                    }
                    .disabled(locationManager.location == nil)
                }

                Section {
                    Button(role: .destructive) {
                        viewModel.deleteMarker(id: marker.id)
                        dismiss()
                    } label: {
                        Text("Marker löschen")
                    }
                }
            }
            .navigationTitle("Marker bearbeiten")
            .toolbar {
                ToolbarItem(placement: .topBarLeading) {
                    Button("Cancel") { dismiss() }
                }
                ToolbarItem(placement: .topBarTrailing) {
                    Button("Save") {
                        viewModel.updateMarker(id: marker.id, title: title, note: note, newCoordinate: nil)
                        dismiss()
                    }
                }
            }
        }
    }
}
