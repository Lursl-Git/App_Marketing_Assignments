import MapKit
import SwiftUI
import Combine
import CoreLocation

final class MapViewModel: ObservableObject {

    // MARK: - Map
    @Published var cameraPosition: MapCameraPosition

    // MARK: - Existing (POIs / Tour / Bezier Route)
    @Published var pointsOfInterest: [POI] = []
    @Published var tourStops: [TourStop] = []
    @Published var currentRoute: [CLLocationCoordinate2D] = []
    @Published var navigationInstructions: [NavigationInstruction] = []
    @Published var totalDistance: Double = 0.0
    @Published var estimatedTime: Double = 0.0

    private var userLocation: CLLocationCoordinate2D?
    private let elevationService = ElevationService()
    private let routeCalculator = BezierRouteCalculator()
    private let defaultSpan = MKCoordinateSpan(latitudeDelta: 0.02, longitudeDelta: 0.02)

    // MARK: - Recording
    @Published var isRecording: Bool = false
    @Published var recordingPath: [CLLocationCoordinate2D] = []
    @Published var recordingDistanceMeters: Double = 0
    @Published var recordingDuration: TimeInterval = 0
    @Published var recordedRoutes: [RecordedRoute] = []

    private var recordingStart: Date?
    private var timerCancellable: AnyCancellable?
    private let store = RecordedRouteStore()

    // MARK: - User Markers
    @Published var userMarkers: [UserMarker] = []
    private let markerStore = UserMarkerStore()

    init() {
        let startRegion = MKCoordinateRegion(
            center: CLLocationCoordinate2D(latitude: 49.2497, longitude: 7.3500),
            span: MKCoordinateSpan(latitudeDelta: 0.05, longitudeDelta: 0.05)
        )
        self.cameraPosition = .region(startRegion)
        self.recordedRoutes = store.load()
        self.userMarkers = markerStore.load()
    }

    // MARK: - Location updates
    func handleLocationUpdate(_ location: CLLocation) {
        userLocation = location.coordinate
        if isRecording {
            appendRecordingPoint(location)
        }
    }

    func centerOnLocation(_ coordinate: CLLocationCoordinate2D) {
        cameraPosition = .region(MKCoordinateRegion(center: coordinate, span: defaultSpan))
    }

    // MARK: - POIs
    func addPOI(_ poi: POI) { pointsOfInterest.append(poi) }
    func removePOI(_ poi: POI) { pointsOfInterest.removeAll { $0.id == poi.id } }

    // MARK: - Tour
    func addToTour() {
        for poi in pointsOfInterest {
            let stop = TourStop(
                coordinate: poi.coordinate,
                name: poi.name,
                order: tourStops.count + 1,
                elevation: poi.elevation
            )
            tourStops.append(stop)
        }
    }

    func clearTour() {
        tourStops.removeAll()
        currentRoute.removeAll()
        navigationInstructions.removeAll()
        totalDistance = 0.0
        estimatedTime = 0.0
    }

    // MARK: - Bezier route calc
    func calculateRoute() {
        guard !tourStops.isEmpty else { return }

        var waypoints = tourStops.sorted { $0.order < $1.order }.map { $0.coordinate }
        if let userLoc = userLocation { waypoints.insert(userLoc, at: 0) }

        currentRoute = routeCalculator.calculateSmoothRoute(waypoints: waypoints)

        totalDistance = calculateTotalDistance(route: currentRoute)
        estimatedTime = (totalDistance / 1000.0) / 5.0 * 60.0

        generateNavigationInstructions()

        Task { await fetchElevationData() }
    }

    private func calculateTotalDistance(route: [CLLocationCoordinate2D]) -> Double {
        guard route.count > 1 else { return 0 }
        var distance: Double = 0
        for i in 0..<(route.count - 1) {
            let a = CLLocation(latitude: route[i].latitude, longitude: route[i].longitude)
            let b = CLLocation(latitude: route[i + 1].latitude, longitude: route[i + 1].longitude)
            distance += a.distance(from: b)
        }
        return distance
    }

    private func generateNavigationInstructions() {
        navigationInstructions.removeAll()
        guard currentRoute.count >= 2 else { return }

        for i in 0..<tourStops.count {
            let stop = tourStops[i]
            let dist = i > 0 ? calculateDistance(from: tourStops[i - 1].coordinate, to: stop.coordinate) : 0
            navigationInstructions.append(
                NavigationInstruction(
                    step: i + 1,
                    description: "Navigate to \(stop.name)",
                    distance: dist,
                    coordinate: stop.coordinate,
                    elevation: stop.elevation
                )
            )
        }
    }

    private func calculateDistance(from: CLLocationCoordinate2D, to: CLLocationCoordinate2D) -> Double {
        CLLocation(latitude: from.latitude, longitude: from.longitude)
            .distance(from: CLLocation(latitude: to.latitude, longitude: to.longitude))
    }

    private func fetchElevationData() async {
        for coordinate in currentRoute {
            _ = await elevationService.getElevation(for: coordinate)
        }
    }

    // MARK: - Recording controls
    func startRecording() {
        guard !isRecording else { return }
        isRecording = true
        recordingPath.removeAll()
        recordingDistanceMeters = 0
        recordingStart = Date()
        recordingDuration = 0

        if let userLocation { recordingPath.append(userLocation) }

        timerCancellable?.cancel()
        timerCancellable = Timer.publish(every: 1, on: .main, in: .common)
            .autoconnect()
            .sink { [weak self] _ in
                guard let self, let start = self.recordingStart else { return }
                self.recordingDuration = Date().timeIntervalSince(start)
            }
    }

    func stopAndSaveRecording() {
        guard isRecording else { return }
        isRecording = false

        timerCancellable?.cancel()
        timerCancellable = nil

        let end = Date()
        let start = recordingStart ?? end
        recordingStart = nil

        guard recordingPath.count >= 2, recordingDistanceMeters >= 10 else { return }

        let newRoute = RecordedRoute(
            startedAt: start,
            endedAt: end,
            distanceMeters: recordingDistanceMeters,
            points: recordingPath
        )

        recordedRoutes.insert(newRoute, at: 0)
        store.save(recordedRoutes)
    }

    func deleteRecordedRoutes(at offsets: IndexSet) {
        recordedRoutes.remove(atOffsets: offsets)
        store.save(recordedRoutes)
    }

    private func appendRecordingPoint(_ location: CLLocation) {
        let coord = location.coordinate
        guard let last = recordingPath.last else {
            recordingPath.append(coord)
            return
        }

        let a = CLLocation(latitude: last.latitude, longitude: last.longitude)
        let d = a.distance(from: location)

        guard d >= 5 else { return }

        recordingPath.append(coord)
        recordingDistanceMeters += d
    }

    // MARK: - Optional helper
    func nearestPOI(to coordinate: CLLocationCoordinate2D) -> POI? {
        guard !pointsOfInterest.isEmpty else { return nil }
        return pointsOfInterest.min {
            calculateDistance(from: coordinate, to: $0.coordinate) < calculateDistance(from: coordinate, to: $1.coordinate)
        }
    }

    // MARK: - User Markers (WICHTIG: innerhalb der Klasse!)
    @discardableResult
    func addMarker(at coordinate: CLLocationCoordinate2D) -> UserMarker {
        let m = UserMarker(coordinate: coordinate)
        userMarkers.insert(m, at: 0)
        markerStore.save(userMarkers)
        return m
    }

    func updateMarker(id: UUID, title: String, note: String, newCoordinate: CLLocationCoordinate2D?) {
        guard let idx = userMarkers.firstIndex(where: { $0.id == id }) else { return }
        var updated = userMarkers[idx]
        updated.title = title.trimmingCharacters(in: .whitespacesAndNewlines)
        updated.note  = note.trimmingCharacters(in: .whitespacesAndNewlines)
        if let c = newCoordinate {
            updated.coordinate = CodableCoordinate(c)
        }
        userMarkers[idx] = updated
        markerStore.save(userMarkers)
    }

    func deleteMarker(id: UUID) {
        userMarkers.removeAll { $0.id == id }
        markerStore.save(userMarkers)
    }
}

// MARK: - Models (wie vorher)
struct POI: Identifiable, Equatable {
    let id = UUID()
    let coordinate: CLLocationCoordinate2D
    let name: String
    let elevation: Double

    static func == (lhs: POI, rhs: POI) -> Bool { lhs.id == rhs.id }
}

struct TourStop: Identifiable {
    let id = UUID()
    let coordinate: CLLocationCoordinate2D
    let name: String
    let order: Int
    let elevation: Double
}

struct NavigationInstruction: Identifiable {
    let id = UUID()
    let step: Int
    let description: String
    let distance: Double
    let coordinate: CLLocationCoordinate2D
    let elevation: Double
}

// MARK: - Elevation Service (wie vorher)
final class ElevationService {
    func getElevation(for coordinate: CLLocationCoordinate2D) async -> Double? {
        try? await Task.sleep(nanoseconds: 100_000_000)
        let base = 200.0
        let variation = sin(coordinate.latitude * 10) * cos(coordinate.longitude * 10) * 100
        return base + variation
    }

    func getElevationProfile(for route: [CLLocationCoordinate2D]) async -> [Double] {
        var out: [Double] = []
        for c in route {
            if let e = await getElevation(for: c) { out.append(e) }
        }
        return out
    }
}
