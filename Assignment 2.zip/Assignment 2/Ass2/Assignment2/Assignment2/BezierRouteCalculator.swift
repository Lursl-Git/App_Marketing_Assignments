import CoreLocation
import Foundation

class BezierRouteCalculator {
    
    // Calculate smooth route using cubic Bezier splines
    func calculateSmoothRoute(waypoints: [CLLocationCoordinate2D], pointsPerSegment: Int = 20) -> [CLLocationCoordinate2D] {
        guard waypoints.count >= 2 else { return waypoints }
        
        var smoothRoute: [CLLocationCoordinate2D] = []
        
        // If only 2 points, create a simple interpolation
        if waypoints.count == 2 {
            return interpolateLinear(from: waypoints[0], to: waypoints[1], steps: pointsPerSegment)
        }
        
        // For each segment between waypoints, create a smooth Bezier curve
        for i in 0..<waypoints.count - 1 {
            let p0 = waypoints[i]
            let p3 = waypoints[i + 1]
            
            // Calculate control points for smooth curve
            let p1 = calculateControlPoint1(current: p0, next: p3, previous: i > 0 ? waypoints[i - 1] : nil)
            let p2 = calculateControlPoint2(current: p0, next: p3, nextNext: i + 2 < waypoints.count ? waypoints[i + 2] : nil)
            
            // Generate points along the Bezier curve
            let curvePoints = generateCubicBezierPoints(
                p0: p0,
                p1: p1,
                p2: p2,
                p3: p3,
                steps: pointsPerSegment
            )
            
            // Add points to route (skip first point of subsequent segments to avoid duplicates)
            if i == 0 {
                smoothRoute.append(contentsOf: curvePoints)
            } else {
                smoothRoute.append(contentsOf: curvePoints.dropFirst())
            }
        }
        
        return smoothRoute
    }
    
    // Generate points along a cubic Bezier curve
    private func generateCubicBezierPoints(
        p0: CLLocationCoordinate2D,
        p1: CLLocationCoordinate2D,
        p2: CLLocationCoordinate2D,
        p3: CLLocationCoordinate2D,
        steps: Int
    ) -> [CLLocationCoordinate2D] {
        var points: [CLLocationCoordinate2D] = []
        
        for i in 0...steps {
            let t = Double(i) / Double(steps)
            let point = cubicBezier(t: t, p0: p0, p1: p1, p2: p2, p3: p3)
            points.append(point)
        }
        
        return points
    }
    
    // Cubic Bezier formula: B(t) = (1-t)³P0 + 3(1-t)²tP1 + 3(1-t)t²P2 + t³P3
    private func cubicBezier(
        t: Double,
        p0: CLLocationCoordinate2D,
        p1: CLLocationCoordinate2D,
        p2: CLLocationCoordinate2D,
        p3: CLLocationCoordinate2D
    ) -> CLLocationCoordinate2D {
        let oneMinusT = 1.0 - t
        let oneMinusT2 = oneMinusT * oneMinusT
        let oneMinusT3 = oneMinusT2 * oneMinusT
        let t2 = t * t
        let t3 = t2 * t
        
        let lat = oneMinusT3 * p0.latitude +
                  3.0 * oneMinusT2 * t * p1.latitude +
                  3.0 * oneMinusT * t2 * p2.latitude +
                  t3 * p3.latitude
        
        let lon = oneMinusT3 * p0.longitude +
                  3.0 * oneMinusT2 * t * p1.longitude +
                  3.0 * oneMinusT * t2 * p2.longitude +
                  t3 * p3.longitude
        
        return CLLocationCoordinate2D(latitude: lat, longitude: lon)
    }
    
    // Calculate first control point for smooth curves
    private func calculateControlPoint1(
        current: CLLocationCoordinate2D,
        next: CLLocationCoordinate2D,
        previous: CLLocationCoordinate2D?
    ) -> CLLocationCoordinate2D {
        let tension = 0.3 // Adjust curve smoothness (0.0 - 1.0)
        
        if let prev = previous {
            // Use the direction from previous to next for smooth transition
            let dirLat = (next.latitude - prev.latitude) * tension
            let dirLon = (next.longitude - prev.longitude) * tension
            
            return CLLocationCoordinate2D(
                latitude: current.latitude + dirLat,
                longitude: current.longitude + dirLon
            )
        } else {
            // First segment: control point closer to current
            return CLLocationCoordinate2D(
                latitude: current.latitude + (next.latitude - current.latitude) * 0.25,
                longitude: current.longitude + (next.longitude - current.longitude) * 0.25
            )
        }
    }
    
    // Calculate second control point for smooth curves
    private func calculateControlPoint2(
        current: CLLocationCoordinate2D,
        next: CLLocationCoordinate2D,
        nextNext: CLLocationCoordinate2D?
    ) -> CLLocationCoordinate2D {
        let tension = 0.3
        
        if let nextNext = nextNext {
            // Use the direction from current to nextNext for smooth transition
            let dirLat = (nextNext.latitude - current.latitude) * tension
            let dirLon = (nextNext.longitude - current.longitude) * tension
            
            return CLLocationCoordinate2D(
                latitude: next.latitude - dirLat,
                longitude: next.longitude - dirLon
            )
        } else {
            // Last segment: control point closer to next
            return CLLocationCoordinate2D(
                latitude: next.latitude - (next.latitude - current.latitude) * 0.25,
                longitude: next.longitude - (next.longitude - current.longitude) * 0.25
            )
        }
    }
    
    // Linear interpolation between two points
    private func interpolateLinear(from: CLLocationCoordinate2D, to: CLLocationCoordinate2D, steps: Int) -> [CLLocationCoordinate2D] {
        var points: [CLLocationCoordinate2D] = []
        
        for i in 0...steps {
            let t = Double(i) / Double(steps)
            let lat = from.latitude + (to.latitude - from.latitude) * t
            let lon = from.longitude + (to.longitude - from.longitude) * t
            points.append(CLLocationCoordinate2D(latitude: lat, longitude: lon))
        }
        
        return points
    }
    
    // Calculate route with elevation consideration
    func calculateElevationAwareRoute(
        waypoints: [CLLocationCoordinate2D],
        elevations: [Double],
        maxGradient: Double = 0.15
    ) -> [CLLocationCoordinate2D] {
        guard waypoints.count == elevations.count else {
            return calculateSmoothRoute(waypoints: waypoints)
        }
        
        var adjustedWaypoints: [CLLocationCoordinate2D] = []
        
        for i in 0..<waypoints.count {
            if i == 0 {
                adjustedWaypoints.append(waypoints[i])
                continue
            }
            
            let elevationDiff = abs(elevations[i] - elevations[i - 1])
            let distance = calculateDistance(from: waypoints[i - 1], to: waypoints[i])
            let gradient = elevationDiff / distance
            
            // If gradient too steep, add intermediate waypoints
            if gradient > maxGradient {
                let intermediatePoints = Int(ceil(gradient / maxGradient))
                for j in 1...intermediatePoints {
                    let t = Double(j) / Double(intermediatePoints + 1)
                    let lat = waypoints[i - 1].latitude + (waypoints[i].latitude - waypoints[i - 1].latitude) * t
                    let lon = waypoints[i - 1].longitude + (waypoints[i].longitude - waypoints[i - 1].longitude) * t
                    adjustedWaypoints.append(CLLocationCoordinate2D(latitude: lat, longitude: lon))
                }
            }
            
            adjustedWaypoints.append(waypoints[i])
        }
        
        return calculateSmoothRoute(waypoints: adjustedWaypoints)
    }
    
    // Calculate distance between two coordinates
    private func calculateDistance(from: CLLocationCoordinate2D, to: CLLocationCoordinate2D) -> Double {
        let fromLocation = CLLocation(latitude: from.latitude, longitude: from.longitude)
        let toLocation = CLLocation(latitude: to.latitude, longitude: to.longitude)
        return fromLocation.distance(from: toLocation)
    }
    
    // Optimize route order using nearest neighbor algorithm
    func optimizeRouteOrder(waypoints: [CLLocationCoordinate2D], startPoint: CLLocationCoordinate2D) -> [CLLocationCoordinate2D] {
        guard waypoints.count > 2 else { return waypoints }
        
        var remaining = waypoints
        var optimized: [CLLocationCoordinate2D] = [startPoint]
        var current = startPoint
        
        while !remaining.isEmpty {
            let nearest = findNearest(to: current, in: remaining)
            optimized.append(nearest)
            remaining.removeAll { $0.latitude == nearest.latitude && $0.longitude == nearest.longitude }
            current = nearest
        }
        
        return optimized
    }
    
    // Find nearest point
    private func findNearest(to point: CLLocationCoordinate2D, in points: [CLLocationCoordinate2D]) -> CLLocationCoordinate2D {
        var nearestPoint = points[0]
        var minDistance = calculateDistance(from: point, to: points[0])
        
        for p in points {
            let distance = calculateDistance(from: point, to: p)
            if distance < minDistance {
                minDistance = distance
                nearestPoint = p
            }
        }
        
        return nearestPoint
    }
}