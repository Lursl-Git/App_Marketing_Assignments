import SwiftUI
import MapKit

struct ContentView: View {
    @StateObject private var locationManager = LocationManager()
    @StateObject private var viewModel = MapViewModel()

    @State private var showingHistory = false
    @State private var selectedMarker: UserMarker?

    var body: some View {
        ZStack {
            Map(position: $viewModel.cameraPosition) {
                UserAnnotation()

                ForEach(viewModel.userMarkers) { m in
                    Annotation(m.title.isEmpty ? "Marker" : m.title, coordinate: m.clCoordinate) {
                        MarkerPin()
                            .onTapGesture { selectedMarker = m }
                    }
                }

                if viewModel.recordingPath.count > 1 {
                    MapPolyline(coordinates: viewModel.recordingPath)
                        .stroke(.red.opacity(0.85), lineWidth: 5)
                }
            }
            .mapControls {
                MapCompass()
                MapScaleView()
            }
            .ignoresSafeArea(edges: [.bottom])
            .safeAreaInset(edge: .top) {
                topStatusBar
                    .padding(.horizontal)
                    .padding(.top, 8)
                    .padding(.bottom, 6)
            }

            VStack {
                Spacer()

                ControlPanel(
                    isRecording: viewModel.isRecording,
                    onSetMarker: {
                        guard let c = locationManager.location?.coordinate else { return }
                        let m = viewModel.addMarker(at: c)
                        viewModel.centerOnLocation(c)
                        selectedMarker = m
                    },
                    onShowHistory: { showingHistory = true },
                    onToggleRecording: {
                        viewModel.isRecording ? viewModel.stopAndSaveRecording() : viewModel.startRecording()
                    }
                )
                .padding(.bottom, 6)
            }
        }
        .sheet(isPresented: $showingHistory) {
            RouteHistoryView(viewModel: viewModel)
        }
        .sheet(item: $selectedMarker) { marker in
            MarkerEditView(marker: marker, viewModel: viewModel, locationManager: locationManager)
        }
        .onAppear {
            locationManager.requestPermission()
            locationManager.startUpdating()
        }
        .onChange(of: locationManager.location) { newLocation in
            if let loc = newLocation {
                viewModel.handleLocationUpdate(loc)
            }
        }
    }

    private var topStatusBar: some View {
        HStack(alignment: .top, spacing: 12) {
            VStack(alignment: .leading, spacing: 6) {
                Text("KuLaDig – Live Track")
                    .font(.headline)

                if let loc = locationManager.location {
                    Text("Lat \(loc.coordinate.latitude, specifier: "%.4f") • Lon \(loc.coordinate.longitude, specifier: "%.4f")")
                        .font(.caption)
                        .foregroundStyle(.secondary)

                    if viewModel.isRecording {
                        Text("REC • \(FormatUtils.distance(viewModel.recordingDistanceMeters)) • \(FormatUtils.duration(viewModel.recordingDuration))")
                            .font(.caption)
                            .foregroundStyle(.red)
                    }
                } else {
                    Text("Warte auf GPS…")
                        .font(.caption)
                        .foregroundStyle(.secondary)
                }
            }

            Spacer()

            Button {
                if let loc = locationManager.location {
                    viewModel.centerOnLocation(loc.coordinate)
                }
            } label: {
                Image(systemName: "location.fill")
                    .font(.system(size: 16, weight: .semibold))
                    .frame(width: 40, height: 40)
            }
            .buttonStyle(.bordered)
        }
        .padding(12)
        .background(.regularMaterial)
        .clipShape(RoundedRectangle(cornerRadius: 16, style: .continuous))
    }
}

// MARK: - UI Components

private struct MarkerPin: View {
    var body: some View {
        Image(systemName: "mappin.circle.fill")
            .font(.system(size: 30, weight: .semibold))
            .foregroundStyle(.orange)
            .background(
                Circle()
                    .fill(.thinMaterial)
                    .frame(width: 34, height: 34)
            )
    }
}

private struct ControlPanel: View {
    let isRecording: Bool
    let onSetMarker: () -> Void
    let onShowHistory: () -> Void
    let onToggleRecording: () -> Void

    var body: some View {
        VStack(spacing: 10) {
            HStack(spacing: 10) {
                Button(action: onSetMarker) {
                    Label("Marker setzen", systemImage: "mappin.and.ellipse")
                        .frame(maxWidth: .infinity)
                }
                .buttonStyle(.bordered)
                .tint(.orange)

                Button(action: onShowHistory) {
                    Label("Verlauf", systemImage: "clock.arrow.circlepath")
                        .frame(maxWidth: .infinity)
                }
                .buttonStyle(.bordered)
                .tint(.blue)
            }

            Button(action: onToggleRecording) {
                Label(isRecording ? "Stop & Save" : "Start Recording",
                      systemImage: isRecording ? "stop.fill" : "record.circle")
                    .frame(maxWidth: .infinity)
            }
            .buttonStyle(.borderedProminent)
            .tint(isRecording ? .red : .blue)
        }
        .padding()
        .background(.thinMaterial)
        .clipShape(RoundedRectangle(cornerRadius: 18, style: .continuous))
        .padding(.horizontal)
        .padding(.bottom)
    }
}
