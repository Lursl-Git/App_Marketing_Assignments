//
//  Assignment2App.swift
//  Assignment2
//
//  Created by Lars Trautmann on 15.01.26.
//

import SwiftUI

@main
struct Assignment2App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
