import Foundation
import MapKit

struct CodableCoordinate: Codable, Hashable {
    let latitude: Double
    let longitude: Double

    init(_ c: CLLocationCoordinate2D) {
        self.latitude = c.latitude
        self.longitude = c.longitude
    }

    var coordinate: CLLocationCoordinate2D {
        CLLocationCoordinate2D(latitude: latitude, longitude: longitude)
    }
}

struct RecordedRoute: Identifiable, Codable {
    let id: UUID
    let startedAt: Date
    let endedAt: Date
    let distanceMeters: Double
    let points: [CodableCoordinate]

    init(id: UUID = UUID(), startedAt: Date, endedAt: Date, distanceMeters: Double, points: [CLLocationCoordinate2D]) {
        self.id = id
        self.startedAt = startedAt
        self.endedAt = endedAt
        self.distanceMeters = distanceMeters
        self.points = points.map(CodableCoordinate.init)
    }

    var duration: TimeInterval { endedAt.timeIntervalSince(startedAt) }
}

struct RecordedRouteStore {
    private let key = "kuladig_recorded_routes_v1"

    func load() -> [RecordedRoute] {
        guard let data = UserDefaults.standard.data(forKey: key) else { return [] }
        return (try? JSONDecoder().decode([RecordedRoute].self, from: data)) ?? []
    }

    func save(_ routes: [RecordedRoute]) {
        guard let data = try? JSONEncoder().encode(routes) else { return }
        UserDefaults.standard.set(data, forKey: key)
    }
}
