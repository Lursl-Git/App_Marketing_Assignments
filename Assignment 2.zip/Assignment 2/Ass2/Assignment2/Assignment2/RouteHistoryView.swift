import SwiftUI
import MapKit

struct RouteHistoryView: View {
    @ObservedObject var viewModel: MapViewModel
    @Environment(\.dismiss) private var dismiss

    var body: some View {
        NavigationStack {
            List {
                if viewModel.recordedRoutes.isEmpty {
                    ContentUnavailableView("Noch keine Routen",
                                           systemImage: "figure.walk",
                                           description: Text("Starte eine Aufzeichnung, laufe ein Stück und speichere sie."))
                } else {
                    ForEach(viewModel.recordedRoutes) { route in
                        NavigationLink {
                            RecordedRouteDetailView(route: route)
                        } label: {
                            RouteRow(route: route)
                        }
                    }
                    .onDelete(perform: viewModel.deleteRecordedRoutes)
                }
            }
            .navigationTitle("Verlauf")
            .toolbar {
                ToolbarItem(placement: .topBarLeading) { EditButton() }
                ToolbarItem(placement: .topBarTrailing) {
                    Button("Done") { dismiss() }
                }
            }
        }
    }
}

private struct RouteRow: View {
    let route: RecordedRoute

    var body: some View {
        VStack(alignment: .leading, spacing: 6) {
            Text(route.startedAt.formatted(date: .abbreviated, time: .shortened))
                .font(.headline)

            HStack(spacing: 12) {
                Label(FormatUtils.distance(route.distanceMeters), systemImage: "map")
                Label(FormatUtils.duration(route.duration), systemImage: "clock")
            }
            .font(.subheadline)
            .foregroundStyle(.secondary)
        }
        .padding(.vertical, 4)
    }
}

struct RecordedRouteDetailView: View {
    let route: RecordedRoute
    @State private var position: MapCameraPosition

    init(route: RecordedRoute) {
        self.route = route
        let coords = route.points.map { $0.coordinate }
        _position = State(initialValue: .region(regionFitting(coords: coords)))
    }

    var body: some View {
        VStack(spacing: 0) {
            Map(position: $position) {
                if route.points.count > 1 {
                    MapPolyline(coordinates: route.points.map { $0.coordinate })
                        .stroke(.red.opacity(0.85), lineWidth: 5)
                }
            }
            .mapControls {
                MapCompass()
                MapScaleView()
            }

            VStack(alignment: .leading, spacing: 10) {
                Text(route.startedAt.formatted(date: .abbreviated, time: .shortened))
                    .font(.headline)

                HStack(spacing: 14) {
                    Label(FormatUtils.distance(route.distanceMeters), systemImage: "map")
                    Label(FormatUtils.duration(route.duration), systemImage: "clock")
                }
                .foregroundStyle(.secondary)
            }
            .padding()
            .frame(maxWidth: .infinity, alignment: .leading)
            .background(.regularMaterial)
        }
        .navigationTitle("Route")
        .navigationBarTitleDisplayMode(.inline)
    }
}

private func regionFitting(coords: [CLLocationCoordinate2D]) -> MKCoordinateRegion {
    guard let first = coords.first else {
        return MKCoordinateRegion(center: CLLocationCoordinate2D(latitude: 49.2497, longitude: 7.3500),
                                  span: MKCoordinateSpan(latitudeDelta: 0.05, longitudeDelta: 0.05))
    }
    guard coords.count > 1 else {
        return MKCoordinateRegion(center: first,
                                  span: MKCoordinateSpan(latitudeDelta: 0.01, longitudeDelta: 0.01))
    }

    var minLat = first.latitude, maxLat = first.latitude
    var minLon = first.longitude, maxLon = first.longitude

    for c in coords {
        minLat = min(minLat, c.latitude); maxLat = max(maxLat, c.latitude)
        minLon = min(minLon, c.longitude); maxLon = max(maxLon, c.longitude)
    }

    let center = CLLocationCoordinate2D(latitude: (minLat + maxLat) / 2, longitude: (minLon + maxLon) / 2)
    let span = MKCoordinateSpan(latitudeDelta: max(0.01, (maxLat - minLat) * 1.6),
                               longitudeDelta: max(0.01, (maxLon - minLon) * 1.6))
    return MKCoordinateRegion(center: center, span: span)
}
